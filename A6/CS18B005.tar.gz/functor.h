class Student
{
public:
	void findavg();
	string getName();
	double getAvg();
	void takeInput();
private:
	string name;
	int rollNo;
	int Mscore;
	int Pscore;
	int Cscore;
	double avg;
}